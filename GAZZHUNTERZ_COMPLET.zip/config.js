// Configuration frontend pour l'API backend
// Remplace la valeur ci-dessous par l'URL publique de ton backend (Render/Railway/Render)
// Exemple Render: https://gazhunters-backend.onrender.com
window.GHZ_CONFIG = {
  API_BASE_URL: 'https://gazhunterz.onrender.com'
};


